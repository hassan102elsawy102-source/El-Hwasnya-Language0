package com.elhwasny.language

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFFF6EDE1.toInt())
        }
        val title = TextView(this).apply {
            text = "El Hwasny-Language"
            textSize = 25f
            setTextColor(0xFF8A5A3B.toInt())
        }
        val info = TextView(this).apply {
            text = "\nكيبورد مستقل لتحويل النص وفك التحويل مباشرة داخل التطبيقات مثل واتساب.\n\n1) فعّل الكيبورد من إعدادات Android.\n2) اختر El Hwasny-Language كلوحة المفاتيح الحالية.\n3) افتح واتساب وابدأ الكتابة.\n\nزر «تحويل» يحوّل آخر كلمة كتبتها، أو النص المحدد إذا قمت بتحديده أولاً."
            textSize = 16f
            setTextColor(0xFF1F1B16.toInt())
        }
        val enable = Button(this).apply {
            text = "تفعيل الكيبورد"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "اختيار الكيبورد"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        box.addView(title)
        box.addView(info)
        box.addView(enable)
        box.addView(choose)
        setContentView(box)
    }
}
