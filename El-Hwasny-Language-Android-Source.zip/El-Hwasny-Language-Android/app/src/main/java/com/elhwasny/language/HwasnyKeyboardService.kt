package com.elhwasny.language

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class HwasnyKeyboardService : InputMethodService() {
    private var english = false
    private var shifted = false
    private var symbols = false
    private var decodeMode = false
    private lateinit var root: LinearLayout
    private lateinit var toolbar: LinearLayout

    private val arabicRows = listOf(
        listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"),
        listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"),
        listOf("ئ","ء","ؤ","ر","لا","ى","ة","و","ز","ظ","د")
    )
    private val englishRows = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("z","x","c","v","b","n","m")
    )
    private val symbolRows = listOf(
        listOf("1","2","3","4","5","6","7","8","9","0"),
        listOf("@","#","$","%","&","-","+","(",")","/"),
        listOf("*","\"","'",":",";","!","?","=")
    )

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 8)
            setBackgroundColor(Color.rgb(218, 222, 229))
        }
        buildKeyboard()
        return root
    }

    private fun buildKeyboard() {
        root.removeAllViews()
        toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = label("El Hwasny", 12f, true)
        toolbar.addView(brand, weight(0.9f))
        toolbar.addView(actionButton(if (decodeMode) "فك" else "تحويل") {
            decodeMode = !decodeMode
            buildKeyboard()
        }, weight(1.1f))
        toolbar.addView(actionButton("تنفيذ") { transformCurrentText() }, weight(1.2f))
        toolbar.addView(actionButton("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, weight(0.8f))
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(42)))

        val rows = when {
            symbols -> symbolRows
            english -> if (shifted) englishRows.map { row -> row.map { it.uppercase() } } else englishRows
            else -> arabicRows
        }
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key -> line.addView(keyButton(key) { commit(key) }, keyWeight(row.size)) }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(49)).apply { topMargin = dp(4) })
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(actionButton(if (symbols) "ABC" else "?123") {
            symbols = !symbols
            buildKeyboard()
        }, weight(1.15f))
        bottom.addView(actionButton("⇧") {
            shifted = !shifted
            buildKeyboard()
        }, weight(0.85f))
        bottom.addView(actionButton(if (english) "عربي" else "EN") {
            english = !english
            symbols = false
            buildKeyboard()
        }, weight(1.0f))
        bottom.addView(keyButton("،") { commit(if (english) "," else "،") }, weight(0.7f))
        bottom.addView(keyButton("مسافة") { commit(" ") }, weight(3.0f))
        bottom.addView(keyButton("↵") {
            val ic = currentInputConnection
            if (ic != null) ic.commitText("\n", 1)
            else requestHideSelf(0)
        }, weight(0.9f))
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(49)).apply { topMargin = dp(4) })
    }

    private fun transformCurrentText() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText(transform(selected.toString(), if (decodeMode) -1 else 1), 1)
            return
        }
        val before = ic.getTextBeforeCursor(500, 0)?.toString().orEmpty()
        if (before.isEmpty()) return
        val boundary = before.indexOfLast { it.isWhitespace() || it in "،,.!?؟؛:" }
        val word = before.substring(boundary + 1)
        if (word.isEmpty()) return
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(transform(word, if (decodeMode) -1 else 1), 1)
    }

    private fun transform(text: String, direction: Int): String {
        val alphabet = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي"
        return buildString {
            text.forEach { ch ->
                val index = alphabet.indexOf(ch)
                append(if (index < 0) ch else alphabet[(index + direction + alphabet.length) % alphabet.length])
            }
        }
    }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
        if (shifted && english) {
            shifted = false
            buildKeyboard()
        }
    }

    private fun label(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.rgb(80, 84, 92))
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun keyButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = if (text.length > 2) 12f else 18f
        isAllCaps = false
        setTextColor(Color.rgb(35, 39, 45))
        background = rounded(Color.WHITE)
        setPadding(0, 0, 0, 0)
        setOnClickListener { click() }
    }

    private fun actionButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 13f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(138, 90, 59))
        setPadding(0, 0, 0, 0)
        setOnClickListener { click() }
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(7).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun weight(value: Float) = LinearLayout.LayoutParams(0, -1, value).apply {
        marginStart = dp(2); marginEnd = dp(2)
    }
    private fun keyWeight(count: Int) = LinearLayout.LayoutParams(0, -1, 1f).apply {
        marginStart = dp(2); marginEnd = dp(2)
    }
}
